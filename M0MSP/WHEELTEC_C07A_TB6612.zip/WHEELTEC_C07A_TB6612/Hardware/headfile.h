#ifndef __HEADFILE_H__
#define __HEADFILE_H__

#include "encoder.h"
#include "led.h"
#include "stdio.h"
#include "string.h"
#include "ti_msp_dl_config.h"
#include "key.h"
#include "motor.h"
#include "encoder.h"
#include "stdlib.h"
#include "math.h"



#endif